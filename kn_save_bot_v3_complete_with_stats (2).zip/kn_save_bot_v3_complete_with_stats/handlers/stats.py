from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command
from utils.users import get_users_count

stats_router = Router()
ADMIN_ID = 7769437481  # Replace with your own Telegram ID

@stats_router.message(Command("stats"))
async def send_stats(message: Message):
    if message.from_user is None:
        return
    if message.from_user.id != ADMIN_ID:
        return await message.answer("⛔ Sizga ruxsat yo‘q!")
    count = get_users_count()
    await message.answer(f"👥 Foydalanuvchilar soni: <b>{count}</b>", parse_mode="HTML")
