from aiogram import Router, F
from aiogram.types import Message
from config import ADMIN_ID

admin_router = Router()

@admin_router.message(F.text == "/stats")
async def stats(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        with open("data/stats.txt") as f:
            users = len(set(f.readlines()))
        await message.answer(f"📊 Foydalanuvchilar soni: {users}")
    except:
        await message.answer("📊 Statistika topilmadi.")
