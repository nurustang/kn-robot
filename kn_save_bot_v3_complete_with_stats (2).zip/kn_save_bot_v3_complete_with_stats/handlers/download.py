import os
from aiogram import Router, F
from aiogram.types import Message, FSInputFile
import yt_dlp

download_router = Router()

async def download_video(url: str, filename: str = "video.%(ext)s"):
    ydl_opts = {
        'outtmpl': filename,
        'format': 'bestvideo+bestaudio/best',
        'merge_output_format': 'mp4'
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        return ydl.prepare_filename(info)

@download_router.message(F.text)
async def handle_links(message: Message):
    if message.from_user is None or message.text is None:
        return
    from handlers.language import get_lang
    url = message.text.strip()
    lang = await get_lang(message.from_user.id)
    if any(domain in url for domain in ["instagram.com", "tiktok.com"]):
        await message.answer("⏳ Yuklanmoqda, kuting..." if lang == "uz" else "⏳ Загрузка, подождите...")
        try:
            filename = await download_video(url)
            await message.answer_video(FSInputFile(filename))
            os.remove(filename)
            with open("data/stats.txt", "a") as f:
                f.write(f"{message.from_user.id}\n")
        except Exception as e:
            await message.answer(f"❌ Xatolik yuz berdi:\n<code>{str(e)}</code>")
    else:
        await message.answer("Instagram yoki TikTok ssilkani yuboring." if lang == "uz" else "Отправьте ссылку на видео Instagram или TikTok.")
