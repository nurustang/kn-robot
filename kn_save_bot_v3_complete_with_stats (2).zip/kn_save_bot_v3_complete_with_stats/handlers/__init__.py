from aiogram import Router
from .download import download_router
from .language import language_router
from .admin import admin_router

router = Router()
router.include_router(language_router)
router.include_router(download_router)
router.include_router(admin_router)
