import os
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.filters import CommandStart
from utils.users import save_user
language_router = Router()
LANG_FILE = "data/lang.txt"

def save_lang(user_id: int, lang: str):
    lines = []
    if os.path.exists(LANG_FILE):
        with open(LANG_FILE, "r") as f:
            lines = f.readlines()

    with open(LANG_FILE, "w") as f:
        found = False
        for line in lines:
            uid, l = line.strip().split(":")
            if int(uid) == user_id:
                f.write(f"{user_id}:{lang}\n")
                found = True
            else:
                f.write(line)
        if not found:
            f.write(f"{user_id}:{lang}\n")

async def get_lang(user_id: int):
    if not os.path.exists(LANG_FILE):
        return "uz"
    with open(LANG_FILE) as f:
        for line in f:
            try:
                uid, l = line.strip().split(":")
                if int(uid) == user_id:
                    return l
            except:
                continue
    return "uz"

@language_router.message(CommandStart())
async def start_handler(message: Message):
    if message.from_user is None:
        return
    save_user(message.from_user.id)
    keyboard = [[KeyboardButton(text="UZ uz"), KeyboardButton(text="RU ru")]]
    reply_markup = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
    await message.answer("Tilni tanlang / Выберите язык", reply_markup=reply_markup)

@language_router.message(F.text == "UZ uz")
async def uz_selected(message: Message):
    if message.from_user is None:
        return
    save_lang(message.from_user.id, "uz")
    await message.answer(
        "✅ Til tanlandi!\n\n🎉 Endi siz <b>KN SAVE BOT</b> xizmatidan foydalanishingiz mumkin.\n\nInstagram yoki TikTok ssilkasini yuboring — video tayyorlab beramiz! 🎬",
        reply_markup=ReplyKeyboardRemove()
    )

@language_router.message(F.text == "RU ru")
async def ru_selected(message: Message):
    if message.from_user is None:
        return
    save_lang(message.from_user.id, "ru")
    await message.answer(
        "✅ Язык выбран!\n\n🎉 Теперь вы можете пользоваться <b>KN SAVE BOT</b>.\n\nОтправьте ссылку с Instagram или TikTok — и мы подготовим видео! 🎬",
        reply_markup=ReplyKeyboardRemove()
    )
